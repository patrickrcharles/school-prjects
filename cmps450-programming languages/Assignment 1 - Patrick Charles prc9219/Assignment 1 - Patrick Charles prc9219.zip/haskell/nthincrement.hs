--author: Patrick Charles prc9212
--class : CMPS 450
--date  : 9/22/15
--assignment #1

--function takes in an integer and returns an nth increment function
--which increments parameters by n
--it evaluates the parenthesis to see if there is another parameter
-- and if there is, it is added to the original one given to the 
--function

nthinc :: Int -> Int -> Int
nthinc x y =  x + y 