// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include <stdio.h>        // FA98
#include <iostream>
#include <iomanip>
#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "addrspace.h"   // FA98
#include "sysdep.h"   // FExceptionTypeA98
#include "list.h"
using namespace std;
// begin FA98

static int SRead(int addr, int size, int id);
static void SWrite(char *buffer, int size, int id);
static void processCreation(int arg);
void CannotFindProcessError();
Thread* getProcessById(int id);

// end FA98

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
	int type = machine->ReadRegister(2);

	int arg1 = machine->ReadRegister(4);
	int arg2 = machine->ReadRegister(5);
	int arg3 = machine->ReadRegister(6);
	int Result;
	int i, j;
	char *ch = new char [500];
	
	//EXEC methods variables
	switch ( which )
	{
		case NoException :
			break;
		case SyscallException :
		
			// for debugging, in case we are jumping into lala-land
			// Advance program counters.
			machine->registers[PrevPCReg] = machine->registers[PCReg];
			machine->registers[PCReg] = machine->registers[NextPCReg];
			machine->registers[NextPCReg] = machine->registers[NextPCReg] + 4;

			switch ( type )
			{
				case SC_Halt :
					printf("Halt has been called by process %i -- Shutting down...\n", currentThread->getId());					
					interrupt->Halt();
					break; //End SC_Halt

				case SC_Read :
					if (arg2 <= 0 || arg3 < 0){
						printf("\nRead 0 byte.\n");
					}
					Result = SRead(arg1, arg2, arg3);
					machine->WriteRegister(2, Result);
					DEBUG('t',"Read %d bytes from the open file(OpenFileId is %d)",	arg2, arg3);
				
					break; //End SC_Read

				case SC_Write :
					for (j = 0; ; j++) {
						if(!machine->ReadMem((arg1+j), 1, &i))
							j=j-1;
						else{
							ch[j] = (char) i;
							if (ch[j] == '\0') 
								break;
						}
					}
					if (j == 0){
						printf("\nWrite 0 byte.\n");
						// SExit(1);
					} else {
						printf("\nWrite %d bytes from %s to the open file(OpenFileId is %d).", arg2, ch, arg3);
						SWrite(ch, j, arg3);
					}
				
					break; //End SC_Write
				
				case SC_Exec :
				{ //Create a scope for Exec because case statements suck
					//Get File Name
					for (j = 0; ; j++) {
						if (!machine->ReadMem(arg1, 1, &i) || i == '\0')
							break; //leave loop
						ch[j] = (char) i; //append to end of string				
						arg1++; //go to next memory location
					}
					//Try to open file and allocate the memory
					OpenFile *executable = fileSystem->Open(ch);
    				AddrSpace *space;
					if (executable == NULL) { //kill if file ain't real (rip)
						cout << "Unable to open file: " << ch << endl;
						break;
					}
					printf("Exec called by process %i -- File opened successfully: \"%s\" (Process %i)\n", 
										currentThread->getId(), ch, nextProcessId);
										
					//fix for recursion... same process cannot open another instance of itself as a process!
					string currentName = currentThread->getName();
					string newName = ch;					
					if (currentName == newName) {
						printf("*** File closed -- Cannot open same file!\n");
						break;
					}
					
					//if valid file, allocate memory.
					space = new AddrSpace(executable);
					delete executable;					
					
					if (space->errorOccurred) {
						printf("*** File closed.\n");
						break; //if error occured during allocation (insufficient), then don't create!						
					}
					
					//Create the thread for the process with global process id
					Thread *t = new Thread(ch, nextProcessId);
					machine->WriteRegister(2, nextProcessId++);		//write the processId back to return register
					t->space = space;
					procPool.Append(t);	//add to process pool
					printf("Process %i added to PCB.\n", t->getId());
					t->Fork(processCreation, 0);
					
					break; //End SC_Exec
				}
				case SC_Join :
				{
					printf("Join on process %i (child) called by process %i (parent).\n", arg1, currentThread->getId());
					Thread* child;
					if (!currentThread->hasChild) {
						child = getProcessById(arg1);
						if (child != NULL) {
							printf("Child Process Found...\n");
							child->setParentId(currentThread->getId());	//set parentId on child
							currentThread->hasChild = true;
							printf("Running Child Process...\n");
							scheduler->Run(child);						//run child							
						} else {
							printf("*** Child process not found.\n");
						}
					} else {
						printf("Parent Process already has child");
					}															
					break; //End SC_Join
				}
				case SC_Exit :
				{
					bool swap = false;
					printf("Exit called by process %i passing '%i' -- Process Removed.\n", currentThread->getId(), arg1);
					
					printf("Checking for parent thread...\n");					
					if (currentThread->getParentId() > 0) {
						printf("Parent Thread Found. Continuing...\n");
						swap = true; //set flag to switch parent and current threads
					} else {
						printf("Parent Thread Not Found.\n");
						swap = false;
					}
					
					delete currentThread->space; //deallocate memory
					
					//perform thread swap before finishing
					if (swap) {
						Thread* parent = getProcessById(currentThread->getParentId());
						parent->hasChild = false;						
						scheduler->Run(parent);
					}
					
					currentThread->Finish();	//finish process
					break; //End SC_Exit
				}
				case SC_Yield :
					printf("Yield called by process %i -- Yielding the CPU to another thread...\n", currentThread->getId());
					currentThread->Yield();
					break; //End SC_Yield
		
				default :
					//Unprogrammed system calls end up here
					printf("Unprogrammed system call by process %i -- Doing nothing...\n", currentThread->getId());
					break; //End Default
			}         
			break;

		case ReadOnlyException :
			puts ("ReadOnlyException");
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			//SExit(1);
			break;
		case BusErrorException :
			puts ("BusErrorException");	
			currentThread->Finish();			
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			
			//SExit(1);
			break;
		case AddressErrorException :
			puts ("Pointer Out Of Bounds!\n");
			currentThread->Finish();
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			//SExit(1);
			break;
		case OverflowException :
			puts ("OverflowException");
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			//SExit(1);
			break;
		case IllegalInstrException :
			puts ("IllegalInstrException");
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			currentThread->Finish();
			//SExit(1);
			break;
		case NumExceptionTypes :
			puts ("NumExceptionTypes");
			if (currentThread->getName() == "main")
			ASSERT(FALSE);  //Not the way of handling an exception.
			//SExit(1);
			break;

			default :
			//      printf("Unexpected user mode exception %d %d\n", which, type);
			//      if (currentThread->getName() == "main")
			//      ASSERT(FALSE);
			//      SExit(1);
			break;
		}
		delete [] ch;
}


static int SRead(int addr, int size, int id)  //input 0  output 1
{
	char buffer[size+10];
	int num,Result;

	//read from keyboard, try writing your own code using console class.
	if (id == 0)
	{
		scanf("%s",buffer);

		num=strlen(buffer);
		if(num>(size+1)) {

			buffer[size+1] = '\0';
			Result = size+1;
		}
		else {
			buffer[num+1]='\0';
			Result = num + 1;
		}

		for (num=0; num<Result; num++)
		{  machine->WriteMem((addr+num), 1, (int) buffer[num]);
			if (buffer[num] == '\0')
			break; }
		return num;

	}
	//read from a unix file, later you need change to nachos file system.
	else
	{
		for(num=0;num<size;num++){
			Read(id,&buffer[num],1);
			machine->WriteMem((addr+num), 1, (int) buffer[num]);
			if(buffer[num]=='\0') break;
		}
		return num;
	}
}

static void SWrite(char *buffer, int size, int id)
{
	//write to terminal, try writting your own code using console class.
	if (id == 1)
	printf("%s", buffer);
	//write to a unix file, later you need change to nachos file system.
	if (id >= 2)
	WriteFile(id,buffer,size);
}

void processCreation(int arg) {
	currentThread->space->InitRegisters(); //initialize registers
	currentThread->space->RestoreState();  //load page table register
	machine->Run();	//run the process
}

void CannotFindProcessError() {
	printf("*** Incorrect process to join on.\n");
}

Thread* getProcessById(int id) {
	//cannot join onto same thread.
	if (id == currentThread->getId()) {
		printf("*** Cannot join onto same thread.\n");
		return NULL;
	}
	//iterate through all threads... join the one with this processId, else, do nothing	
	Thread *child = NULL;
	if (!procPool.IsEmpty()) {
		//Find process in procPool							
		ListElement* head = procPool.GetFirst();
		ListElement* tail = NULL;
		for (int t = 0; t < procPool.GetLength(); t++) {
			Thread* ele = static_cast<Thread*>(head->item);
			if (ele->getId() == id) {
				child = ele;
				break;
			} else {
				tail = head;
				head = head->next;
			}
		}
		if (child == NULL) {
			CannotFindProcessError(); //if no child in process pool, alert and dont run
			return NULL;
		}
		return child;
		
	} else {
		CannotFindProcessError();
		return child;
	}
}
// end FA98

