#include "syscall.h"




main()
{
   
Exec("../test/test1");

    Yield();
Exit(0);
}
