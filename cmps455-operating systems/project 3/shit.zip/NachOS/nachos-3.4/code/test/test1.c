/* test1.c
 *	Simple program to test whether running a user program works.
 *	
 *	call fork, exec memory
 *
 */

#include "syscall.h"

int
main()
{
	Exec("../test/fork");
	

	Exec("../test/exec");
	
	Exec("../test/memory");

	Exit(0);

	
}
