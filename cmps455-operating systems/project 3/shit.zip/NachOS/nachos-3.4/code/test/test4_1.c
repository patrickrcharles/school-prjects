#include "syscall.h"



main()
{   int i;
    
    for(i=0;i<5;i++) 
	{
	Yield();
	}
	
	Exec("../test/test4_2");

	Exit(0);
}
