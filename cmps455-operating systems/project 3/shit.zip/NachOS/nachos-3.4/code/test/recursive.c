#include "syscall.h"

int main() {

	SpaceId rec = Exec("../test/recursive");	
	Join(rec);
}
