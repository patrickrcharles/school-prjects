/* test4_2.c */
/* --------- testing all system calls       */
/* --------- size of the program : 14 pages */

#include "syscall.h"



int main()
{
  int i;
  char buffer[25];
  
for( i=0 ; i < 25 ; ++i ) 
{
	buffer[i] = 'a';
}


Exit(0);

}
