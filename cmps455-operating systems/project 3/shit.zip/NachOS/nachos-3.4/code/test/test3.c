
#include "syscall.h"

void foo()
{

  Exec("../test/exec");
}


int main()
{
    Fork(foo);
    Yield();
    Exec("../test/test3_1");
	
    Fork(foo);
	Exit(0);
}
