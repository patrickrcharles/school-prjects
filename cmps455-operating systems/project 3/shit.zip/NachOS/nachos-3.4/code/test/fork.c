#include "syscall.h"

void f()
{
	Exec("../test/test1");
}


main()
{
	//Exec("../test/test1");
 	
	Fork(f);

}
