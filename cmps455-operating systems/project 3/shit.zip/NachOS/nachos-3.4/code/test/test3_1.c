/* test3_1.c */
/* --------- testing system calls : Exit, Exec, Join */
/* --------- size of the program : 11 pages          */

#include "syscall.h"

int main()
{
  Exec("../test/test3_2");
  Exit( 0 );
}
