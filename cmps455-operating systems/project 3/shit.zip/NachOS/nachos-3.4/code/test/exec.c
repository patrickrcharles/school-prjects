#include "syscall.h"

void useMem()
{
	Exec("../test/fork");
}

int main()
{

	Fork(useMem);
	Yield();

	Exit(0);
}
