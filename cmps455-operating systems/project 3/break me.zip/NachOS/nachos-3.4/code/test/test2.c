/* test2.c
 *	Simple program to test whether running a user program works.
 *	
 *	be careful to allocate a big enough stack to hold the automatics!
 */

#include "syscall.h"

void foo(int s)
{
  char buf[60];

  Exec("../test/matmult");
  Close("../test/matmult");
  
}


int main()
{
   
    Fork(foo);
    Yield();
    Exec("../test/test");

    
	Exit(0);


}
