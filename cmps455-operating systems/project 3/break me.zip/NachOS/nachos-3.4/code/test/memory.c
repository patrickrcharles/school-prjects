#include "syscall.h"


int array[100];

int main()
{
	
int i = 0;

for (i = 0; i < 5; i++) 
{
	array[i] = i+2;

}	

	Exit(0);
}
