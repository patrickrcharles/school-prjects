
#include "syscall.h"

void func()
{
	Exec("../test/test");
}

int main()
{

//invalid filename test

//Exec("../test/testA");

//invalid system calls

//char a[100] = {'../test/test'};


//Open();
//Close(a;
Fork(func);
func();
Exit(0);
}
