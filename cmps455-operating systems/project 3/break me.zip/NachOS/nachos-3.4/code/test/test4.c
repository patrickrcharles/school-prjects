#include "syscall.h"

int
main()
{
   
    int i ;

    for(i=0;i<2;i++)
	{
	Exec("../test/test4_1"); 
	Yield();
	} 
	Exit(0);
}
