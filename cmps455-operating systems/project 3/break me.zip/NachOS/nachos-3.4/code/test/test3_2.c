/* test3_2.c */
/* --------- testing system calls : Exit, Exec, Join */
/* --------- size of the program : 11 pages          */

#include "syscall.h"

int main()
{
  
  Yield();
  Exit(0);
}
