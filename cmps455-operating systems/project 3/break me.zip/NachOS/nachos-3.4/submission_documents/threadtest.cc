// threadtest.cc 
//	Simple test case for the threads assignment.
//
//	Create two threads, and have them context switch
//	back and forth between themselves by calling Thread::Yield, 
//	to illustratethe inner workings of the thread system.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include <iostream>
#include <string>
#include <sstream>
#include <synch.h>
using namespace std;

//Prototypes
string ValidateInput(string input); //Returns type of input
string IntToString(int num);		//Converts an int to string
void OutputState(int index);		//Outputs state of philosopher
void CheckMail(int thisPerson);		//Action to check a specific person's mailbox

//STAGE 2: Variables Task 1-2
int numPhils = 1;							//Number of Philosophers for arrays
int meals;									//Number of meals
int mealsEaten;								//Number of meals eaten
int rCount = 0;								//Philosophers in room
int tCount = 0;								//Philosophers at table
bool *chopsticks = new bool[numPhils]; 		//True: On Table
int *philosophers = new int[numPhils];		//Philosopher states
int onTableChopsticks;
//-1: Initialized
//0 : Entered room
//1 : Sat at table
//2 : Picked up left chopstick
//3 : Picked up right chopstick
//4 : Eating
//5 : Put down left chopstick
//6 : Put down right chopstick
//7 : Thinking
//8 : Waiting to Leave Table

//Semaphores
Semaphore** chopsems;		//Chopstick Semaphore Array
Semaphore* sit; 			//Semaphore to pause for etiquette (to sit down)
Semaphore* begin;			//Semaphore to pause for etiquette (to start)
Semaphore** mySemaphore;

//Post Office Globals
int messagesToSend;
int messagesSent = 0;
int numParticipants;
int maxMessages;
int** mailboxes;
//PATRICK's GLOBALS
int sentCounter;
int mailbox[10000][10001];
int mailboxMessages[10000];

// BEGIN CODE CHANGES BY PATRICK CHARLES
bool
isEmpty(int threadID)
{
	int k = 1; //row starts at index1. index0 is threadID
	bool status = true;
	while (k <= maxMessages) {
		if (mailbox[threadID][k] == 0) { //if message slot is empty
			status = true;
		} else { //if not 0, will break
			status = false;
		}
		k++;
	}
	return status;  //true = empty mailbox
}

void
sendMessage(int threadID)
{
	int randomPerson;
	int randomPattern = Random() % 10;	
	
	//Find Random Person
	while (true) {
		randomPerson = Random() % numParticipants;
		if (randomPerson != threadID)
			break;
	}
	
	mySemaphore[randomPerson]->P();			//wait until slot is open
	for (int i = 1; i <= maxMessages; i++) { //scan person's mailbox
		if (mailbox[randomPerson][i] == 0) { //if message slot is empty
			mailbox[randomPerson][i] = 1; // flag empty slot as having message
			if (sentCounter != messagesToSend)
				//printf("......Person %d is trying to send Pattern %d to Person %d.\n", threadID, randomPattern, randomPerson);
			
			mySemaphore[threadID]->V();

			int cycles = (Random() % 5) + 2;
			while (cycles > 0) {
				currentThread->Yield();
				cycles--;
			}
			
			if (isEmpty(randomPerson) == true) { // if recipicient's mailbox is empty
				if (sentCounter < messagesToSend) {
					mailboxMessages[randomPerson]++; //increase counter for that person's mailbox
					printf(".........Person %d has sent Pattern %d to Person %d.\n", threadID, randomPattern, randomPerson);
					break;
				}
			} else if (isEmpty(randomPerson) == true) {
				printf("...Person %d's mailbox is full.\n", randomPerson);
			}				
		}
	}
	if (sentCounter < messagesToSend) {
		mySemaphore[randomPerson]->P();  //wait semaphore to accept message
		sentCounter++;  //increase counter for number of messages sent
		if (sentCounter <= messagesToSend)
			printf("...............Person %d has sent message Number %d.\n", threadID, sentCounter);
		if (sentCounter == messagesToSend) {
			printf("All %d message(s) have been sent.\n", messagesToSend);
		}
	}
}

void
readMessage(int threadID) //need to read until 1 is found, then break
{
	printf("...Person %d checks mailbox...\n", threadID);
	int counter = 0; //counter for num messages in mailbox
	
	for (int i = 1; i <= messagesToSend; i++) { // scan mailbox row 
		if (mailbox[threadID][i] == 1) { //if message slot is not empty
			counter++; // num messages in current mailbox
		}
	}

	if (counter >= 0) { // if person has mail
		printf("......Person %d has %d message(s) in mailbox.\n", threadID, mailboxMessages[threadID]);			
	}
	
	counter = mailboxMessages[threadID]; // forget why but it works
	
	for (int j = 1; j <= counter; j++) { //read each message
		printf("......Person %d has read Message %d.\n", threadID, j);
		mailboxMessages[threadID]--; 	//decrement # messages for person
		mySemaphore[threadID]->V();		//Signal after reading (slot opened up)
		mailbox[threadID][j] = 0; 		//read message, empty slot
		
	}
	
	if (mailboxMessages[threadID] == 0) { //if empty
		printf("......Person %d's mailbox is empty.\n", threadID);
	}	
}

void
Person(int threadID)
{
	while(sentCounter < messagesToSend) {	
		printf("Person %d enters post office.\n", threadID);
		
		readMessage(threadID); 	//Read All Messages
		currentThread->Yield();	//Yield before sending msg
		sendMessage(threadID);	//Send a Message
		
		printf("...............Person %d has left the post office.\n", threadID);
		
		//Left Post Office, Yeild 2-5 Cycles
		int cycles = (Random() % 4) + 2;
		while (cycles > 0) {
			currentThread->Yield();
			cycles--;
		}		
	}
	currentThread->Finish();
}

void
PostOffice2()
{
	//initialize matrix for mailbox
	for (int i = 0; i < numParticipants; i++) {
		mailboxMessages[i] = 0;
		for (int j = 0; j < maxMessages+1; j++) {
			mailbox[i][j] = 0; // set mailboxes to empty with zeroes
			mailbox[i][0] = i; // set person index
		}	
	}
	
	mySemaphore = new Semaphore*[numParticipants]; //dynamic allocation of semaphors

	//create array of semaphores
	for (int i = 0; i < numParticipants; i++) {
		mySemaphore[i] = new Semaphore("debug", maxMessages); //each mail slot
	}
	
	//fork threads
	for (int i = 0; i < numParticipants; i++) {
		Thread* t = new Thread("thread");
		t->Fork(Person, i);
	}	
}

void
Task6(int which)
{	
	// GET ALL INPUTS
	string input1;
	string input2;
	string input3;
	
	//# of participants
	cout << "Enter number of participants: ";
	cin >> input1;
	if (ValidateInput(input1) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	// Max Messages in Inbox
	cout << "Enter maximum amount of messages per inbox: ";
	cin >> input2;
	if (ValidateInput(input2) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	// Messages to be sent
	cout << "Enter number of messages to be sent: ";
	cin >> input3;
	if (ValidateInput(input3) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	//INITIALIZATION [Converting]	
	numParticipants = atoi(input1.c_str());
	maxMessages = atoi(input2.c_str());
	messagesToSend = atoi(input3.c_str());
	
	// Error value checks
	string error = "***ERROR: ";
	if (numParticipants <= 1 || maxMessages == 0 || messagesToSend == 0) {
		if (numParticipants <= 1) {
			error += "Participants needs to be greater than 1. ";
		} 
		if (maxMessages == 0) {
			error += "Max Inbox Messages needs to be greater than 0. ";
		} 
		if (messagesToSend == 0) {
			error += "Messages To Send needs to be greater than 0. ";
		}
		if (maxMessages > 10000) {
			error += "Max Inbox Messages cannot surpass 10,000. ";
		}
		if (numParticipants > 10000) {
			error += "Participants cannot surpass 10,000. ";
		}
		cout << error << endl;
		return;
	}
	
	PostOffice2();

	currentThread->Finish();
}
// END CODE CHANGES BY PATRICK CHARLES

// BEGIN CODE CHANGES BY ERIK SCHNEIDER
void
CheckMail(int thisPerson)
{
	bool messageReceived;
	if (messagesSent == messagesToSend) { //leave if all messages have been sent
		return;
	}
	printf("-Person %i enters the post office \n", thisPerson);
	printf("-Person %i is checking their mail...\n", thisPerson);
		
	for (int i = 0; i < maxMessages; i++) {
		messageReceived = false;
		if (mailboxes[thisPerson][i] != 0) {
			string msg;
			switch(mailboxes[thisPerson][i])
			{
				case 1	:
				{
					msg = "Hello";
					break;
				}
				case 2:
				{
					msg = "Goodbye";
					break;
				}
				case 3:
				{
					msg = "Help me";
					break;
				}
				case 4:
				{
					msg = "Oh god why";
					break;
				}
				case 5:
				{
					msg = "This is fine";
					break;
				}
				case 6:
				{
					msg = "I am fine.";
					break;
				}
				case 7:
				{
					msg = "Where am I?";
					break;
				}
				case 8:
				{
					msg = "Who am I?";
					break;
				}
				case 9:
				{
					msg = "WHAT YEAR IS IT?";
					break;
				}
			}
			cout << "[ " << msg << " ]\n";
			printf("--Person %i is reading a message in their %ith mailbox slot\n\n", thisPerson, i);
			messageReceived = true;
			mailboxes[thisPerson][i] = 0;
			currentThread->Yield(); //reading msg
		}
		if (i == maxMessages - 1 && messageReceived == false) {
			printf("--Person %i received no new messages :(\n", thisPerson);
		}
	}	
}

void
PostOffice1(int thisPerson)
{
	//int messagesSent = 0;
	int randomPerson;
	bool waitingToSendMessage = true;
	bool messageReceived;
	int timesAttempted;
	
	while (messagesToSend > messagesSent) {
		waitingToSendMessage = true;
		CheckMail(thisPerson);
		while (true) {
			randomPerson = Random() % numParticipants;
			if (randomPerson != thisPerson)		//loop until not sending to self
				break;
		}

		while (waitingToSendMessage) {
			//Sending Message
			for (int i = 0; i < maxMessages; i++) { //finding an empty slot in their mailbox
				if (messagesSent == messagesToSend) { //break if max messages has been sent
					printf("All %i messages have been sent!\n", messagesToSend);
					break;
				}
			
				if (mailboxes[randomPerson][i] == 0) { //if slot is empty
					int randomMessage = (Random() % 8) +1;
					mailboxes[randomPerson][i] = randomMessage;								
					printf("---Person %i has successfully sent a message to person %i. (%i total messages sent)\n", thisPerson, randomPerson, ++messagesSent);
					waitingToSendMessage = false;
					break;
				}
			}
			
			if (messagesSent == messagesToSend) { //End Algorithm if all messages sent!
				break;
			}
			
			//If inbox is full
			if (waitingToSendMessage) {
				timesAttempted++;
				printf("---Person %i is trying to send a message to person %i, but their mailbox is full!! \n", thisPerson, randomPerson);
				printf("---Person %i has tried sending a letter %i times\n", thisPerson, timesAttempted);
					
				currentThread->Yield();
				if (timesAttempted == 3) {
					printf("---Person %i has tried sending a letter to Person %i three times now. Deadlock prevention here\n", thisPerson, randomPerson);
						
					waitingToSendMessage = false;
					timesAttempted = 0;
					break;
				}
			}
		}
		
		printf("----Person %i has left the building!\n\n", thisPerson);
		
		if (messagesSent == messagesToSend) { //End Algorithm if all messages sent!
				break;
		}
		int cycles = (Random() % 4) + 2;
		
		while(cycles > 0) {
			currentThread->Yield();
			cycles--;
		}
	}
}

void 
Task5(int which)
{
	// GET ALL INPUTS
	string input1;
	string input2;
	string input3;
	
	//# of participants
	cout << "Enter number of participants: ";
	cin >> input1;
	if (ValidateInput(input1) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	// Max Messages in Inbox
	cout << "Enter maximum amount of messages per inbox: ";
	cin >> input2;
	if (ValidateInput(input2) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	// Messages to be sent
	cout << "Enter number of messages to be sent: ";
	cin >> input3;
	if (ValidateInput(input3) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	
	//INITIALIZATION [Converting]	
	numParticipants = atoi(input1.c_str());
	maxMessages = atoi(input2.c_str());
	messagesToSend = atoi(input3.c_str());
	
	// Error value checks
	string error = "***ERROR: ";
	if (numParticipants <= 1 || maxMessages == 0 || messagesToSend == 0) {
		if (numParticipants <= 1) {
			error += "Participants needs to be greater than 1. ";
		} 
		if (maxMessages == 0) {
			error += "Max Inbox Messages needs to be greater than 0. ";
		} 
		if (messagesToSend == 0) {
			error += "Messages To Send needs to be greater than 0. ";
		}
		cout << error << endl;
		return;
	}
	
	mailboxes = new int*[numParticipants];			//first dimension
	for (int i = 0; i < numParticipants; i++) { 
		mailboxes[i] = new int[maxMessages];		//second dimension
	}
	
	for (int i = 0; i < numParticipants; i++) {
		for (int j = 0; j < maxMessages; j++) {						
			mailboxes[i][j] = 0; // (empty slot in mailbox)
		}
	}
	
	for (int i = 0; i < numParticipants; i++) {
		Thread *t = new Thread("BusyWaitingPostOffice");
		t->Fork(PostOffice1, i);
	}
	
	currentThread->Finish();
}
// END CODE CHANGES BY ERIK SCHNEIDER

// BEGIN CODE CHANGES BY ADAM MIER
void
DPSemaphor(int index) {
	//Enters Room
	philosophers[index] = 0;	
	OutputState(index);
	rCount++;
	
	//Sitting down Semaphore
	while (rCount < numPhils) {
		sit->P();
	}
	sit->V();
		
	//Sit at table
	philosophers[index] = 1;
	OutputState(index);
	tCount++;
	
	//Wait for everyone to sit at table
	while (tCount < numPhils) {
		begin->P();
	}
	begin->V();
	
	//Begin algorithm
	do {
		// Left and Right chopstick variables
		int left; 
		int right; 
		if (numPhils == 1) {
			left = 0;
			right = 1;
		} else {
			left = index;
			right = (index + 1) % numPhils;
		}
		bool hasLeft = false;
		bool hasRight = false;
					
		//Check to see if Left Chopstick is available
		if (mealsEaten != meals)
		{
			cout << "--Philosopher " << index << " is attempting to pick up left chopstick\n";
			if (onTableChopsticks == 1) {
				if (numPhils != 1) {
					cout << "*** Philosopher " << index << " is preventing deadlock by not picking up the last chopstick!\n";
					currentThread->Yield();
					continue;
				}
			}
			chopsems[left]->P();
			onTableChopsticks--;
			philosophers[index] = 2;
			hasLeft = true;
			OutputState(index);
		}		
		
		//Check to see if Right Chopstick is available
		if (mealsEaten != meals)
		{
			cout << "--Philosopher " << index << " is attempting to pick up right chopstick\n";
			chopsems[right]->P();
			onTableChopsticks--;
			philosophers[index] = 3;
			hasRight = true;
			OutputState(index);
		}

		//Eating
		if ((mealsEaten != meals) && hasLeft && hasRight) {
			mealsEaten = mealsEaten + 1;
			philosophers[index] = 4;
			OutputState(index);
			cout << "----Philosopher " << index << " is eating for 1 cycle.\n";
			currentThread->Yield(); //cycle 1
			cout << "----Philosopher " << index << " is eating for 2 cycles.\n";
			currentThread->Yield(); //cycle 2
			for (int i = 0; i < Random() % 4; i++) {
				cout << "----Philosopher " << index << " is eating for " << (3 + i) << " cycles.\n";
				currentThread->Yield(); // cycle 3-5
			}
		}

		//Put down left chopstick
		if (hasLeft) {
			chopsems[left]->V();
			onTableChopsticks++;
			philosophers[index] = 5;
			OutputState(index);
			hasLeft = false;
		}

		//Put down right chopstick
		if (hasRight) {
			chopsems[right]->V();
			onTableChopsticks++;
			philosophers[index] = 6;
			OutputState(index);
			hasRight = false;
		}
		
		//Begin thinking
		philosophers[index] = 7;
		OutputState(index);
		cout << "----Philosopher " << index << " is thinking for 1 cycle.\n";
		currentThread->Yield(); //cycle 1
		cout << "----Philosopher " << index << " is thinking for 2 cycles.\n";
		currentThread->Yield(); //cycle 2
		for (int i = 0; i < Random() % 4; i++) {
			cout << "----Philosopher " << index << " is thinking for " << (i + 3) << " cycles.\n";
			currentThread->Yield(); // cycle 3-5
		}
	} while (mealsEaten != meals);
	
	//Ready to leave table
	philosophers[index] = 8;
	OutputState(index);
	
	//Last thread check!
	bool done = true;
	for (int i = 0; i < numPhils; i++) 
	{
		if (philosophers[i] != 8)
			done = false;
	}
	if (done) {
		cout << "~!~!~ All philosophers leave together hand in hand. ~!~!~\n";
	}
	//Finish
	currentThread->Finish();
}
//END CODE CHANGES BY ADAM MIER
//BEGIN CODE CHANGES BY HAROLD HANSEN
void
DPBusyWaiting(int index) {
	//Enters Room
	philosophers[index] = 0;
	OutputState(index);
	currentThread->Yield();
	
	//Loop while waiting for everyone to enter room
	bool error = false;
	do {
		error = false;
		currentThread->Yield();
		for (int i = 0; i < numPhils; i++) {
			if (philosophers[i] < 0)
				error = true;
		}
	} while (error);
	
	//Sit at table
	philosophers[index] = 1;
	OutputState(index);
	currentThread->Yield();
	
	//Wait for everyone to sit at table
	error = false;
	do {
		currentThread->Yield();
		error = false;
		for (int i = 0; i < numPhils; i++) {
			if (philosophers[i] < 1)
				error = true;
		}
	} while (error);
	
	do {
		// Left and Right chopstick variables
		int left; 
		int right; 
		if (numPhils == 1) {
			left = 0;
			right = 1;
		} else {
			left = index;
			right = (index + 1) % numPhils;
		}
		bool hasLeft = false;
		bool hasRight = false;

		//Check to see if Left Chopstick is available
		cout << "--Philosopher " << index << " is attempting to pick up left chopstick\n";
		int onTableChopsticks = 0;
		for (int i = 0; i < numPhils; i++) {
			if (chopsticks[i] == true)
				onTableChopsticks++;
		}
		while (chopsticks[left] == false) {
			currentThread->Yield();
		}
		
		if (numPhils > 1 && onTableChopsticks == 1) {
			cout << "*** Philosopher " << index << " is preventing deadlock by not picking up the last chopstick!\n";
			currentThread->Yield();
			continue;
		}
		
		//Picked up left chopstick
		if (mealsEaten != meals) {
			chopsticks[left] = false;
			philosophers[index] = 2;
			hasLeft = true;
			OutputState(index);
		}
		
		//Check to see if Right Chopstick is available
		cout << "---Philosopher " << index << " is attempting to pick up right chopstick\n";
		while (chopsticks[right] == false) {
			cout << left << " WAT " << right << " WAT!?\n";
			currentThread->Yield();
		}
				
		//Picked up right chopstick
		if (mealsEaten != meals) {
			chopsticks[right] = false;
			philosophers[index] = 3;
			hasRight = true;
			OutputState(index);
		}
		
		//Eating
		if ((mealsEaten != meals) && hasLeft && hasRight) {
			mealsEaten++;
			philosophers[index] = 4;
			OutputState(index);
			cout << "----Philosopher " << index << " is eating for 1 cycle.\n";
			currentThread->Yield(); //cycle 1
			cout << "----Philosopher " << index << " is eating for 2 cycles.\n";
			currentThread->Yield(); //cycle 2
			for (int i = 0; i < Random() % 4; i++) {
				cout << "----Philosopher " << index << " is eating for "<< (i + 3) << " cycles.\n";
				currentThread->Yield(); // cycle 3-5
			}
		}

		//Put down left and right chopstick
		if (hasLeft) {
			//Left
			chopsticks[left] = true;
			philosophers[index] = 5;
			OutputState(index);
			hasLeft = false;
		}

		//Put down right chopstick
		if (hasRight) {
			//Right
			chopsticks[right] = true;
			philosophers[index] = 6;
			OutputState(index);
			hasRight = false;
		}
	
		//Begin thinking
		philosophers[index] = 7;
		OutputState(index);
		cout << "----Philosopher " << index << " is thinking for 1 cycle.\n";
		currentThread->Yield(); //cycle 1
		cout << "----Philosopher " << index << " is thinking for 2 cycles.\n";
		currentThread->Yield(); //cycle 2
		for (int i = 0; i < Random() % 3; i++) {
			cout << "----Philosopher " << index << " is thinking for "<< (i + 3) << " cycles.\n";
			currentThread->Yield(); // cycle 3-5
		}
	} while (mealsEaten != meals);
	
	//Ready to leave table
	philosophers[index] = 8;
	OutputState(index);
	
	//Last thread check!
	bool done = true;
	for (int i = 0; i < numPhils; i++) 
	{
		if (philosophers[i] != 8)
			done = false;
	}
	if (done)
		cout << "~!~!~ All philosophers leave together hand in hand. ~!~!~\n";
	
	//Finish
	currentThread->Finish();
}

//----------------------------------------------------------------------
// OutputState
//
// 	Outputs the state of a specific philosopher.
//
//----------------------------------------------------------------------
void
OutputState(int index) {
	int state = philosophers[index];
	if (state == 0)
		cout << "Philosopher " << index << " has entered the room.\n";
	else if (state == 1)
		cout << "-Philosopher " << index << " has seated at the table.\n";
	else if (state == 2)
		cout << "--Philosopher " << index << " picked up left chopstick.\n";
	else if (state == 3)
		cout << "---Philosopher " << index << " picked up right chopstick.\n";
	else if (state == 4)
		cout << "----Philosopher " << index << " is eating meal number " << mealsEaten << ".\n";
	else if (state == 5)
		cout << "-----Philosopher " << index << " has put down left chopstick.\n";
	else if (state == 6)
		cout << "------Philosopher " << index << " has put down right chopstick.\n";
	else if (state == 7)
		cout << "-------Philosopher " << index << " is thinking.\n";
	else if (state == 8)
		cout << "--------Philosopher " << index << " is ready to leave.\n";
}

//----------------------------------------------------------------------
// DiningPhilosopher
//
// 	Dining Philosophers algorithm. Will fork threads based on 'which'
//
//	WHICH:
//		0 = Busy Waiting Loops version
//		1 = Semaphors version
//
//----------------------------------------------------------------------
void
DiningPhilosophers(int which) {
	string sPhilosophers;
	string sMeals;
	
	//Get inputs
	cout << "Enter number of philosophers (Positive Integer): ";
	cin >> sPhilosophers;
	if (ValidateInput(sPhilosophers) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	cout << "Enter number of meals (Positive Integer): ";
	cin >> sMeals;
	if (ValidateInput(sMeals) != "POS INT") {
		cout << "Invalid Input!\n";
		return;
	}
	
	//Convert inputs after validation
	int numPhilosophers = atoi(sPhilosophers.c_str());
    int numMeals = atoi(sMeals.c_str());
    
    // More Bad Input catches
    if (numPhilosophers <= 0) {
    	cout << "Need at least 1 meal!\n";
    	return;
    }
    
    //Initialize global variables;
    numPhils = numPhilosophers;
    meals = numMeals;
    mealsEaten = 0;
    philosophers = new int[numPhils];
    begin = new Semaphore("start", 0);
    sit = new Semaphore("sit", 0);
    onTableChopsticks = numPhils;
    
    // Special Cases
    if (numPhils == 1) {
    	chopsems = new Semaphore*[2];
    	chopsticks = new bool[2];
    } else {
    	chopsems = new Semaphore*[numPhils];
    	chopsticks = new bool[numPhils];
    }
    
    //Initialize all philosopher/chopstick variables
    if (numPhilosophers == 1) {
    	for (int i = 0; i < 2; i++) {
			if (which == 0) {
				philosophers[i] = -1;
		   		chopsticks[i] = true;
			} else if (which == 1) {
				chopsems[i] = new Semaphore("Semaphor", 1);
			} else {
		   		cout << "Error.\n";
		   		return;
	   		}
    	}
    } else {
		for (int i = 0; i < numPhilosophers; i++) {
		   	if (which == 0) { //Busy Waiting Loop
		   		philosophers[i] = -1;
		   		chopsticks[i] = true;
		   	} else if (which == 1) { //Semaphore
		   		chopsems[i] = new Semaphore("Semaphor", 1);
		   	} else {
		   		cout << "Error.\n";
		   		return;
	   		}
		}
    }
    //Fork threads
    for (int i = 0; i < numPhils; i++) {
		Thread *p = new Thread("phil");
		if (which == 0) {
		 	p->Fork(DPBusyWaiting, i); //Busy Waiting Loop Version
		} else if (which == 1) {      		
			p->Fork(DPSemaphor, i); 	//Semaphor Version
		}
    }
    currentThread->Finish();
}
//END CODE CHANGES BY HAROLD HANSEN

//BEGIN CODE CHANGES BY HAROLD HANSEN && ADAM MIER
void
DoRandomShouting() {
    //Six Distinct Shouts....lol
    string shouts[] = {
    	"HEY. LISTEN!",
    		"¯\\_(ツ)_/¯",
    	"┌∩┐(◣_◢)┌∩┐",
    	"( ͡° ͜ʖ ͡°)",
    	"(╯°□°）╯︵ ┻━┻",
    	"༼ つ ◕_◕ ༽つ"
    };
    cout << currentThread->getName() << ": " << shouts[Random() % 6] << endl;
}

void
ThreadShouting(int times) 
{
    for (int i = 0; i < times; i++)
    {
    	int rand = Random() % 4; //random number between 0-3
    	
    	currentThread->Yield(); //Yield Once
    	currentThread->Yield(); //Yield Twice
    	
		for (int j = 0; j < rand; j++) //Random total yields between 2 and 5
		{
			currentThread->Yield();
		}
        DoRandomShouting();
    }
}

//----------------------------------------------------------------------
// ValidateInput
// 	Validates input and determines its type -- Returns a string  
//	representation of what it is.
//
//	To Use:
//		string result = ValidateInput(input);
//
//	Returns:
//		"CHARACTER STRING"  =  string/char array
//		         "POS INT" 	=  positive integer
//		         "NEG INT"	=  negative integer
//				 "POS DEC"  =  positive decimal
//				 "NEG DEC"  =  negative decimal
//----------------------------------------------------------------------
string
ValidateInput(string input)
{
	//Empty Input handling early
	if (input == "\n")
		return "CHARACTER STRING";

	//Convert input to char array
	char exp[256] = "";
	strcpy(exp, input.c_str());
	
	//All numbers
    string nums = "0123456789";
	
	//Counters
    int periods   = 0;
    int negatives = 0;
    int numbers   = 0;
    int chars     = 0;
    
    //Count special characters
    for (int i=0; i<256; i++)
    {
        if (exp[i] != '\000')
        {
    	    if (exp[i] == '.')
    	        periods++;
    	    else if (nums.find(exp[i]) != string::npos)
    	        numbers++;
    	    else if (exp[i] == '-')
    	    	negatives++;
    	    else if (exp[i] == '\n') { } //Catch endline character and do nothing
    	    else
    	    	chars++;
    	}
    }
    
	//Logic for determining
	if (chars > 0 || negatives > 1 || periods > 1)
	{
		return "CHARACTER STRING";
    } 
    else
    {
        if (exp[0] == '.' || (negatives > 0 && exp[0] != '-'))
            return "CHARACTER STRING";
        else
        {
            // first character is '-'
            if (exp[0] == '-' && exp[1] == '.')
                return "CHARACTER STRING";
            else if (negatives > 0 && periods == 1)
            {
                //Second character is not '.'
                //Flags
                bool error = false;
                //Find period, and check stuff after period
                for (int i=0; i<256; i++)
                {
                    if (exp[i] == '.' && exp[i+1] == '\n')
                        error = true;                        
                }
                if (error) 
                    return "CHARACTER STRING";
                else
                    return "NEG DEC";
            }
            else if (negatives > 0 && periods == 0)
            {
                return "NEG INT";
            }
            else if (negatives == 0 && periods > 0)
            {
                //Second character is not '.'
                //Flags
                bool error = false;
                //Find period, and check stuff after period
                for (int i=0; i<256; i++)
                {
                    if (exp[i] == '.' && (exp[i+1] == '\n' || exp[i+1] == ' '))
                        error = true;                        
                }
                if (error) 
                    return "CHARACTER STRING";
                else
                    return "POS DEC";
            }
            else if (negatives == 0 && periods == 0)
            {
                return "POS INT";
            }
        }
    }
}

//----------------------------------------------------------------------
// Task1
// 	Asks user for # of threads and # of shouts. Threads have shout match
//----------------------------------------------------------------------
void
Task2(int task) 
{     
    string threadnum;
    string shoutnum;
    
    cout << "Enter Number of Threads (170000 max): ";
    cin >> threadnum;
    if (ValidateInput(threadnum) != "POS INT") //VALIDATE THREAD INPUT
    {
		cout << "\n*** Invalid input.  Enter a positive integer." << endl;
		return;
	}
    
    cout << "Enter number of Shouts: ";
    cin >> shoutnum;
	if (ValidateInput(shoutnum) != "POS INT") //VALIDATE SHOUTS INPUT
	{
		cout << "\n*** Invalid input.  Enter a positive integer." << endl;
		return;
	}
	
    //Conversion after validation
    int threads = atoi(threadnum.c_str());
    int shouts = atoi(shoutnum.c_str());
    
    //Kill if thread count > 170,000
    if (threads > 170000)
    {
    	cout << "\n*** Insufficient memory for threads. Aborting.\n";
    	return;
    }
    
    //Create number of threads
    for (int i = 0; i < threads; i++)
    {
        string name = "Shouter ";
        name += IntToString(i + 1);
        char* newName = new char[56];
        strcpy(newName, name.c_str());
        
        //Initialize and fork thread
        Thread *t = new Thread(newName);
        t->Fork(ThreadShouting, shouts);
    }
    currentThread->Finish(); //Kill this thread after other threads are forked
}

//----------------------------------------------------------------------
// Task1
// 	Calls our ValidateInput method for Task1
//----------------------------------------------------------------------
void
Task1(int task)
{
    //Get input
    char exp[256] = "";
    printf("Enter arbitrary input (256 characters max, spaces are characters): ");
    fgets(exp, 256, stdin);
            
    string result = ValidateInput(exp); //Get type of input!
    //Outputs
    if (result == "CHARACTER STRING") 
    	printf("You entered a character string!\n\n");
    else if (result == "POS INT")
    	printf("You entered a positive integer!\n\n");
    else if (result == "POS DEC")
    	printf("You entered a positive decimal!\n\n");
    else if (result == "NEG DEC")
    	printf("You entered a negative decimal!\n\n");
    else if (result == "NEG INT")
    	printf("You entered a negative integer!\n\n");
}

//----------------------------------------------------------------------
// ThreadTest
// 	Covnerts an integer to string
//----------------------------------------------------------------------
string
IntToString(int num)
{
    stringstream out;
    out << num;
    string x = out.str();
    return x;
}

//----------------------------------------------------------------------
// ThreadTest
// 	Invoke a test routine.
//----------------------------------------------------------------------
void
ThreadTest()
{
    if (threadTestTask == 1) // ./nachos -A 1
    {    	
    	Thread *t1 = new Thread("Task 1 Thread");
    	t1->Fork(Task1, 1);
    } 
    else if (threadTestTask == 2) // ./nachos -A 2
    {    	
    	Thread *t = new Thread("Task 2 Thread");
    	t->Fork(Task2, 2);
    } 
    else if (threadTestTask == 3) //  ./nachos -A 3
    {
    	Thread *t = new Thread("Task 3 Thread");
		t->Fork(DiningPhilosophers, 0);
    }
    else if (threadTestTask == 4) //  ./nachos -A 4
    {
    	Thread *t = new Thread("Task 4 Thread");
    	t->Fork(DiningPhilosophers, 1);
    }
    else if (threadTestTask == 5) //  ./nachos -A 5
    {
    	Thread *t = new Thread("Task 5 Thread");
    	t->Fork(Task5, 0);
    }
    else if (threadTestTask == 6) //  ./nachos -A 6
    {
    	Thread *t = new Thread("Task 6 Thread");
    	t->Fork(Task6, 0);
    }
    else if (threadTestTask == 0) // ./nachos -A or ./nachos
    {
    	cout << "No arguments detected.\n\n";
    	currentThread->Finish();
    }
    else if (threadTestTask == -1) // bad input
    {
    	cout << "*** Invalid argument or input. Aborting.\n\n";
    	currentThread->Finish();

    }
}

